/*Problem: Write a program named polynomial.js, that evaluates the polynomial shown here:
x^2 – 4x + 7 where x = 3
*/

var x = 3

var expo = Math.pow(x,2)
var multi = 4 * x


console.log(expo - multi + 7);